// Content script for Twitter integration
(function() {
    'use strict';
    
    // Add Reply Guy button to tweets
    function addReplyGuyButtons() {
        const tweets = document.querySelectorAll('[data-testid="tweet"]:not(.reply-guy-processed)');
        
        tweets.forEach(tweet => {
            tweet.classList.add('reply-guy-processed');
            
            // Find the reply button container
            const replyButton = tweet.querySelector('[data-testid="reply"]');
            if (replyButton && replyButton.parentElement) {
                const container = replyButton.parentElement;
                
                // Create Reply Guy button
                const replyGuyBtn = document.createElement('button');
                replyGuyBtn.className = 'reply-guy-btn';
                replyGuyBtn.innerHTML = '🔥';
                replyGuyBtn.title = 'Generate AI Reply';
                
                replyGuyBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    
                    // Extract tweet text
                    const tweetText = tweet.querySelector('[data-testid="tweetText"]');
                    if (tweetText) {
                        // Send message to extension popup
                        chrome.runtime.sendMessage({
                            action: 'fillTweet',
                            tweetText: tweetText.textContent.trim()
                        });
                        
                        // Show notification
                        showNotification('Tweet sent to Reply Guy! Open the extension to generate a reply.');
                    }
                });
                
                // Insert after reply button
                container.insertBefore(replyGuyBtn, replyButton.nextSibling);
            }
        });
    }
    
    // Show notification
    function showNotification(message) {
        const notification = document.createElement('div');
        notification.className = 'reply-guy-notification';
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.classList.add('show');
        }, 100);
        
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }
    
    // Initialize
    function init() {
        addReplyGuyButtons();
        
        // Watch for new tweets (Twitter is a SPA)
        const observer = new MutationObserver(() => {
            addReplyGuyButtons();
        });
        
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }
    
    // Wait for page to load
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
    
    // Listen for messages from popup
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'getTweetText') {
            const tweetText = extractTweetText();
            sendResponse({ tweetText });
        }
    });
    
    function extractTweetText() {
        const tweetSelectors = [
            '[data-testid="tweet"] [data-testid="tweetText"]',
            '[role="article"] [data-testid="tweetText"]'
        ];
        
        for (const selector of tweetSelectors) {
            const elements = document.querySelectorAll(selector);
            if (elements.length > 0) {
                for (const element of elements) {
                    if (element.offsetParent !== null) {
                        return element.textContent.trim();
                    }
                }
            }
        }
        
        return null;
    }
})();